<?php
/**
 * Title: Index Title
 * Slug: blockstarter/index-title
 * Categories: blockstarter
 * Inserter: no
 */
?>

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Latest Posts', 'blockstarter' ); ?></h2>
<!-- /wp:heading -->
